<?php
// Database configuration
include './database/dbconfig.php';

// Select all users with active investments from the users table
$sql = "SELECT u.id, u.available_withdrawals, u.withdrawal_count, u.profit, u.referralBonus, SUM(i.package_amount) AS total_investment 
        FROM users u
        LEFT JOIN investment i ON u.id = i.id
        GROUP BY u.id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Loop through each user
    while ($user = $result->fetch_assoc()) {
        $userId = $user['id'];
        $totalInvestment = $user['total_investment'] ?? 0; // Use 0 if no investment found
        $withdrawalCount = $user['withdrawal_count'];
        $profit = $user['profit'] ?? 0;
        $referralBonus = $user['referralBonus'] ?? 0;
        $availableWithdrawals = $user['available_withdrawals'];

        if ($withdrawalCount == 4) {
            // Add profit + referralBonus to available withdrawals
            $totalAddition = $profit + $referralBonus;
            $updateSql = "UPDATE users 
                          SET available_withdrawals = available_withdrawals + ?, 
                              withdrawal_count = 0 
                          WHERE id = ?";
            $stmt = $conn->prepare($updateSql);
            $stmt->bind_param("di", $totalAddition, $userId);

            if ($stmt->execute()) {
                echo "User ID $userId: Profit and referral bonus added to available withdrawals, withdrawal count reset to 0.\n";
            } else {
                echo "User ID $userId: Error updating withdrawals and resetting count - " . $stmt->error . "\n";
            }
            $stmt->close();
        } else {
            // Calculate 25% of the total investment
            $weeklyWithdrawalAmount = $totalInvestment * 0.25;

            // Increment the withdrawal count and update available withdrawals
            $updateSql = "UPDATE users 
                          SET available_withdrawals = available_withdrawals + ?, 
                              withdrawal_count = withdrawal_count + 1 
                          WHERE id = ?";
            $stmt = $conn->prepare($updateSql);
            $stmt->bind_param("di", $weeklyWithdrawalAmount, $userId);

            if ($stmt->execute()) {
                echo "User ID $userId: Weekly withdrawal amount added, withdrawal count incremented.\n";
            } else {
                echo "User ID $userId: Error updating available withdrawals and withdrawal count - " . $stmt->error . "\n";
            }
            $stmt->close();
        }
    }
} else {
    echo "No users found in the database.\n";
}

// Close the database connection
$conn->close();
?>
